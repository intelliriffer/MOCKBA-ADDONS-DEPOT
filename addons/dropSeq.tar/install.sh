#!/bin/sh

appname=dropseq
appTitle=DropSeq
appDir=DropSeq

################ NO NEED TO EDIT BELOW THIS LINE ###############

mmPath=$(cat /dev/shm/.mmPath)
. $mmPath/MockbaMod/env.sh

runDir="$mmPath/AddOns/"
installroot="$mmPath/AddOns/$appDir/"
runScript="$runDir/run_$appname.sh"

echo "
***********************************************************
*   $appTitle Sequence AddOn Installer for Mockba Mod       *
***********************************************************
"

runner='
#!/bin/sh
############################################################
# Copy this File to $mmPath/AddOns to Launch Automatically
###########################################################

# Set up the environment
mmPath=$(cat /dev/shm/.mmPath)
. $mmPath/MockbaMod/env.sh

if test "$1" == "kill"; then
    killall '$appname' 2&>/dev/null
else
    $mmPath/AddOns/'"$appDir/$appname -v  2>/dev/null"'   &
fi
'

INSTALL() {
    mkdir -p "$installroot"
    cp -rf ./payload/* "$installroot"
    echo "$runner" >"$runScript"
    echo "$runner" >"$installroot/run_$appname.sh"
    echo ">>> $appTitle has Been Installed to: $installroot"
    "$runScript"
    echo "$appTitle has Been launched!"
}

killall $appname 2>/dev/null
if [ -d "$installroot" ]; then
    read -p "$appTitle Already Seems to be Installed.. Replace? (y/n)" yesno
    [[ "$yesno" == "y" ]] && INSTALL
else
    INSTALL
fi
