#!/bin/sh

appname=dropseq
appTitle=DropSeq
appDir=DropSeq

################ NO NEED TO EDIT BELOW THIS LINE ###############

mmPath=$(cat /dev/shm/.mmPath)
. $mmPath/MockbaMod/env.sh

runDir="$mmPath/AddOns/"
installroot="$mmPath/AddOns/$appDir/"
runScript="$runDir/run_$appname.sh"

echo "
***********************************************************
*   DropSeq Sequence AddOn UnInstaller for Mockba Mod      *
***********************************************************
"
if [[ -e "$installroot" ]]; then
    killall $appname 2>/dev/null
    rm -rf "$installroot/"
    rm -f "$runScript" &
    >/dev/null
    echo "<<<< $appTitle has been UnInstalled."
    echo
fi
