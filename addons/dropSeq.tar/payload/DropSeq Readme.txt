*******************************************************************************
DropSEQ - You May Never Know What You Gonna Get.. v 0.1.2d
*******************************************************************************

A unique Weight & Drop Based  Dynamic Midi Note Sequencer** for Akai Force, Akai MPC, Raspberry Pi and Mac OSX (intel)

Please Visit Github Repo for latest Documentation, Download and Source Code: https://github.com/intelliriffer/DROPSEQ-SEQUENCER


## Features
1. 4 Independent Tracks (Channels)
2. Different Time Divisions / Channel
3. Different Note duration (Gate) / Channel
4. Different Sequences / Channel
5. Auto Sequence Regeneration  / Channel




## Installation: 
1. If Using Mockba Mod and my NodeJs App Server, Copy All the Files into your 662522/AddOns/nodeServer/modules Folder and use web to  start/stop  it.

2. If not using my NodeApp server, you can copy the dropseq file anywhere on your device and run using ssh shell (perhaps someone can better explain the process).
or if using Mockba/Kick Gen Mod, you can put in a launch script in their respective autolaunch directors to launch this in background on Startup.



## Setup:
1. Load the Provided Midi Track in Force
2. Set its midi output to Mockba DropSeq, out ch to 16 (all channels work right now),
3. Set Input to none for Now.
4. Create your instrument track(s) set input to ch: 1 for example: and input port to Mockba DropSeq.
5. Start play on Force, it should start playing Channel 1 sequence.
6. Repeat for other Channels. (go to DropSeq Control Track Midi Control to edit Settings : shift +  clip)
7. First 3 Pages on Midi Control are Setup, Pages 4-7 Are for Setting up Note Weights for each Channel