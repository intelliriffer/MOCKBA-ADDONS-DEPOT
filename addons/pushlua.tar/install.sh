#!/bin/sh

appname=PushLua
appTitle=PushLua
appDir=PushLua

################ NO NEED TO EDIT BELOW THIS LINE ###############

mmPath=$(cat /dev/shm/.mmPath)
. $mmPath/MockbaMod/env.sh

runDir="$mmPath/AddOns/"
installroot="$mmPath/AddOns/$appDir/"
runScript="$runDir/run_$appname.sh"

echo "
***********************************************************
*   $appTitle  AddOn Installer for Mockba Mod       *
***********************************************************
"

runner='
mmPath=`cat /dev/shm/.mmPath`
. $mmPath/MockbaMod/env.sh

if test "$1" == "kill"; then
    killall -2 pushlua
else
    if test `lsusb | grep Push | wc -l` == "1"; then
        cd $mmPath/AddOns/PushLua/bin/
        ./pushlua ../LUA/main.lua > /tmp/PushLua.log 2>&1 &
    fi
fi
'

INSTALL() {
    echo "Please Wait.. Copying Files..."
    mkdir -p "$installroot"
    cp -rf ./payload/* "$installroot"
    echo "$runner" >"$runScript"
    echo "$runner" >"$installroot/run_$appname.sh"
    echo ">>> $appTitle has Been Installed to: $installroot"
    "$runScript"
    echo "$appTitle has Been launched!"
}

killall $appname 2>/dev/null
if [ -d "$installroot" ]; then
    read -p "$appTitle Already Seems to be Installed.. Overwrite? (y/n)" yesno
    [[ "$yesno" == "y" ]] && INSTALL
else
    INSTALL
fi
