-- PushLua - Yet another Ableton Push Lua Framework
-- (c) 2021 - Mockba the Borg
-- This code is distributed under the "IDGAFAWYDWTCALAYGMPC" license, which means:
-- I Don't Give A Fuck About What You Do With This Code As Long As You Give Me Proper Credit
--

-- Global variables
device = "push"	-- Must be defined to the device name (filename)

version = "1.02"

-- MIDI messages
midiNoteOff = 0x80
midiNoteOn = 0x90
midiNotePressure = 0xA0
midiControl = 0xB0
midiProgramChange = 0xC0
midiChannelPressure = 0xD0
midiPitchBend = 0xE0
midiSysEx = 0xF0

-- MIDI CC
midiCCSustain = 64

-- Button CCs
buttonNotes = 50
buttonOctDown = 54
buttonOctUp = 55
buttonScales = 58
buttonUser = 59
buttonDuplicate = 88
buttonDelete = 118
buttonUndo = 119
buttonLaunch1 = 43
buttonLaunch2 = 42
buttonLaunch3 = 41
buttonLaunch4 = 40
buttonLaunch5 = 39
buttonLaunch6 = 38
buttonLaunch7 = 37
buttonLaunch8 = 36
buttonStop = 29
buttonUpArrow = 46
buttonDownArrow = 47

-- Knob CCs
knobTempo = 14
knobVolume = 15
knob1 = 71
knob2 = 72
knob3 = 73
knob4 = 74
knob5 = 75
knob6 = 76
knob7 = 77
knob8 = 78
knob9 = 79

-- Button lighting
off = 0
dim = 1
dimBlink = 2
dimBlinkFast = 3
lit = 4
litBlink = 5
litBlinkFast = 6

-- Dual color button lighting
dimRed = 1
dimRedBlink = 2
dimRedBlinkFast = 3
litRed = 4
litRedBlink = 5
litRedBlinkFast = 6
dimOrange = 7
dimOrangeBlink = 8
dimOrangeBlinkFast = 9
litOrange = 10
litOrangeBlink = 11
litOrangeBlinkFast = 12
dimLime = 13
dimLimeBlink = 14
dimLimeBlinkFast = 15
litLime = 16
litLimeBlink = 17
litLimeBlinkFast = 18
dimGreen = 19
dimGreenBlink = 20
dimGreenBlinkFast = 21
litGreen = 22
litGreenBlink = 23
litGreenBlinkFast = 24

-- Other values
buttonPress = 127
