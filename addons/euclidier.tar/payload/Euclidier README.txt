*******************************************************************************
Euclidier - 8 Channel Midi Euclidean Note Sequencer for Force/MPC Beta 0.1.9
*******************************************************************************


Please Visit Github Repo for latest Documentation and Source Code:

https://github.com/intelliriffer/EUCLIDIER-CONSOLE
------------------------------------------------------------------------------

Features:
1. 8 Independent Channels/Tracks
2. Custom Midi Channel Per Track
3. Upto 4 - 32 Steps / Channel
4. Custom Note Pitch / Channel
5. Velocity + Velocity Humanization / Channel  (Adds/Subtracts values up defined (max 32) from Base Velocity).
6. Sequence Shifting (Offset)
7. Different Note/Time Divisions per channel.
8. CC Sequencing : *See Below
9. Realtime Note Based Transpostion
10. Will run on Force and Raspberry Pi
11. ** v 0.1.4 Added Loop Parameter, Loop Parameter Sets the Sequence Restart Point. Values > Steps Creates Polythythms 
12. ** 0.1.5
    1. Added Realtime Note Triggered Transpostion - See below for details.
    2. Extended Steps to 2-64
    
13. New Midi Mapping Layout with Loop Controls added
14. *** 0.1.6 New Killer Features
    1.  Velocity Sense (Default On) : Note Octave will be Shifted based on Incoming Note Velocities
        1.  Velocity < 22 : Octave -1
        2.  Velocity 23 - 126 : octave 0 (As the Orginal Note)
        3.  Velocity 127 : octave +1, Notes will wrap if beyong range;
    2.  CC Sequencing : Any Track can Now be configured as Note Track or a CC.
        1.  Mode Value :1 => Note Track
        2.  Mode Value: 2 => CC Track For Each Trigger CC same as Note Parameter Will be Triggered with Value of "VALUE ALT" and after Gate Duration Default "BASE VALUE" will be trigged. in a Nutshell It will strigger two different CC values.
        3.  Mode Value: 3 A Random Value Between "BASE VALUE" and "VALUE ALT" will be Triggered, after Gate Duration Default "BASE VALUE" will be trigged.
        4.  By Enabling Control on Euclidier Midi Port and only Soloing the CC Track, you can midi learn the cc and then apply to any automatable parameter on Force tracks/fx/ or send to External MIDI/CV.
    3.  Custom Progresisons (Chord Pads) Support : I have hand Created Few Progression files that you can load on your Akai Force/MPC and can use to send some triad chords to Euclidier to create chord stabs or quick custom apreggios (Majors,Minors and Sus4 Chords.) Please Refer to included Readme.txt with the Chords.
    4.  Parameter Names have been changed on Midi Track Template to Make it Easier.
    5.  Some Memory Optimizations (more will come later).
    6.  Added Midi CC/ Params for :
        1.  Reset Octave and any Transpose Applied (All Tracks).
        2.  Vel Sense:
            1.  0: OFF, Will not change octaves based on incoming note velocity.
            2.  1: ON, Will Change octaves based on incoming note velocity.
        3.  RECEIVE NOTES : (0-1) : Switches Realtime Note Input Respose Off/On.

15.  **** **v 0.1.7 Features****
     1.   128 Presets Slots to Save / Load  ( Supports program change loading)
     2.   Master Sync (CC 50, 0-8): Parameter Update Quantization (default 1/4) : Changes to Steps, Fill, Shift etc are quantized to  master clock from none to up to 8 bars.
     3.   When using console, loaded preset values display.
     4.   Preset Feedback Update, If your midi control is set to receive from euclidier on chn16, Euclidier will send the respective cc back to your control surface (mpc/ akai force) to Update the UI parameters.
     5.   Assignable Channels Reduced to 1-15 (Ch:16 is now reserved for feedback msssages.)
     6.   Many Stability Optimizations.
     7.   Added Drum to Track Type. When Trac is set to Drum (2) , it will not transpose or shift octaves on incoming notes. Might be use-for for other purposes in future.
16: Internal Clock added
17. **** v 0.1.9 features
    1.  Randomizer Added (See Below)
    2.  Bug fix for Drum mode.
  
Installation: 
1: to Disable autolaunch remove run_euclicier from /Addons Folder. you can copy files to Addons from Euclidier again to autolaunch.

Notes:
1: If you change Steps, Pulses, Shift parameters or enable a channel , you need to start and stop Force playback to sync the sequences. (I may update this later on to auto sync once I figure out the best way)

2: There is No GUI (I may create web Gui later on ), but a Force Track Template is provided Will all parameters named and Mapped.
4: The Last 4 channels are Defaulted to ch 10,  with notes and simple pattern set for a Drum Kit.
5: The Sequencer might crash (itself  and not Force) sometimes for some values (I need to look into that)
6: It might consume 2-3% cpu as internal resolution is set to 100 microseconds (1/10 ms);


Setup:
1: Load the Provided Track in Force
2: Set its midi output to Mockba Euclidier, out ch to 16 (all channels work right now),
4: Set Input to none for Now.
5: Create your instrument track(s) set input to ch: 1 for example: and port to Mockba Euclidier.
6: Start play on Force, it should start playing 1 channel sequence.
7: Repeat for other Channels. (go to Eculider track midi control to edit Settings : shift +  clip)
8: for Drum testing load as Kit, Set input to Mockba Euclidier, and input channel to 10. set monitoring to in or merge.
9: On Control track enable channels 5-8 (pages3-4) (5 = kick)








