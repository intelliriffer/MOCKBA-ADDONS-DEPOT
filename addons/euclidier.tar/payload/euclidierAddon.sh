#!/bin/sh

#copy this file and euclider executable to /media/662522/AddOns and reboot Akai Force

/media/662522/AddOns/euclidier -v&
