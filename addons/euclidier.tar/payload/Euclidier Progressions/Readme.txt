Eculidier Progressions are Specially designed to play chords on Euclidier Control Channel.
Do not Use on other midi/plugin tracks.

Installation:
1. You Must have a Progressions Folder under root of your SSD/SD Card
2. Copy this   folder to your the above Progressions Folder.
3. Restart Akai Force.
4: These Progressions shuld Appear under Euclider Menu in Progressions.

Usage:
1: Set Eculidier Control Track Note mode to Progressions
2: Load One of The Progressions files
3: Set Root note  to C (its default).
4: Set Octave to -2.
5: The Are velocity Responseive and Velocity Control Octave. Can be tuned of in Eculidier Control panel. or send Fixed Velocity.
6: These Use the first three Tracks of Eculidier to form a Triad Chord.
7: for octave spanning , you can set euclidier notes to different octaves, like track 1: 48, track2: 60, track3: 72 ..
8: Having all track play Same pattern will result in  Chord Stabs.
8: Having all tracks play Different (roted, looped etc) pattern will result in Arppeggition.
Thus you can now create custom changing Arpeggio patterns on the fly and are autmateable too. ;)
~enjoy







